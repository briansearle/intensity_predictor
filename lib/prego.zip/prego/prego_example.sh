#!/bin/sh

./prego.sh /net/maccoss/vol5/home/sonia810/public_html/public/Prego/biognosys_4835_uniprot.peptides.txt /net/maccoss/vol5/home/sonia810/public_html/public/prego_results/biognosys_prego.txt
